# Android APK build

This project includes a GitHub Actions workflow at `.github/workflows/build-apk.yml`.

## Build from a phone

1. Create a GitHub repository and upload this project.
2. Open **Actions** in the repository.
3. Select **Build Lucky Chat APK**.
4. Choose **Run workflow** (or push to `main`).
5. Wait for the job to finish.
6. Open the completed workflow run and download the **LuckyChat-debug-apk** artifact.
7. Extract `LuckyChat-debug.apk` and install it on Android.

The workflow creates the Android project with Capacitor, syncs the `web/` application, runs Gradle, and uploads the resulting debug APK.

## Important

The debug APK is installable for testing but is not a production release. For Play Store/distribution use, create a private Android signing keystore and add a separate signed-release workflow. Never commit the keystore or passwords to GitHub.
