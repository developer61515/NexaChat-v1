# Lucky Chat server starter

Node/Express + Socket.IO realtime starter. It intentionally uses in-memory storage so the project can run immediately. For production, replace the Map with PostgreSQL/Redis, add authentication, object storage, rate limits, validation, and HTTPS.

```bash
npm install
npm start
```
